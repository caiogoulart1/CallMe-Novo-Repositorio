import {  StyleSheet } from "react-native";

export const style = StyleSheet.create({

    TextCheckBox: {
        fontWeight: 'bold',
        color: 'white',
    }


})